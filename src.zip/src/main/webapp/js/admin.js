/*
function adminUserList(){
	fetch("/admin/user")
	.then(response => response.json())
	.then(data=>{
		console.log(data);
	}).catch(err=> {
		console.log(err);
	});
}*/

/*function adminReviewList(page) {
	
}*/




