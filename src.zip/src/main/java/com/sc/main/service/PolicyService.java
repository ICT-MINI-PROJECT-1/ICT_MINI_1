package com.sc.main.service;

public interface PolicyService {
    String getPolicyContent(String policyName);
}